﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using NUnit.Compatibility;
using NUnit.Framework;
namespace InframonHCPTest1
{
    class Program
    {
        static void Main(string[] args)
        {
            // setup
            IWebDriver driver = new FirefoxDriver();
            string homeUrl = "https://hcp-inframoncsp-test.azurewebsites.net/";
            driver.Url = homeUrl;

            // email input
            var email = driver.FindElement(By.Id("i0116"));
            email.SendKeys("");

            // next button press
            var nextBtn1 = driver.FindElement(By.Id("idSIButton9"));
            nextBtn1.Click();

            // password input
            var password = driver.FindElement(By.Id("i0118"));
            password.SendKeys("");
            Thread.Sleep(2000);

            // sign in button press
            var signIn = driver.FindElement(By.Id("idSIButton9"));
            signIn.Click();

            // final button press
            var nextBtn2 = driver.FindElement(By.Id("idBtn_Back"));
            nextBtn2.Click();
            Thread.Sleep(8000);

            var adminNavHamburger = driver.FindElement(By.ClassName("admin-nav-hamburger"));
            adminNavHamburger.Click();

            var azureAdmin = driver.FindElement(By.CssSelector("[href*='/AzureBluePrint'"));
            azureAdmin.Click();
            Thread.Sleep(10000);

            bool treePresent;
            
            IsElementPresent(By.XPath("//i[@class='tree-caret fa  fa-caret-right']"));

            if (treePresent.Equals(true))
            {
                //driver.FindElement(By.XPath("//li[@class='ng-scope']")).Click();

                //driver.FindElement(By.CssSelector("#tree-list li:nth-of-type(4)")).Click();

                /* first child: will return "Option 1"
                driver.FindElement(By.CssSelector("ul.tree-list > li:nth-child(1)")).Click();

                // second child: will return "Option 2"
                driver.FindElement(By.CssSelector("ul.tree-list > li:nth-child(2)"));

                // 3rd child: will return "Option 3"
                driver.FindElement(By.CssSelector("ul.tree-list > li:nth-child(3)"));

                // 4th child: will return "Option 4"
                driver.FindElement(By.CssSelector("ul.tree-list > li:nth-child(4)"));

                // nth child: will return "Option n"
                driver.FindElement(By.CssSelector("ul.tree-list > li:nth-child(n)")).Click();*/

                var iTag = driver.FindElement(By.XPath("//i[@class='tree-caret fa  fa-caret-right']"));
                iTag.Click();
                var aTag = iTag.FindElement(By.XPath(".."));
                aTag.Click();
                IsElementPresent(By.XPath("//ul[@class='tree-sub-list ng-scope']"));
                Thread.Sleep(5000);
                if (treePresent.Equals(true))
                {
                    var mainHeader = driver.FindElement(By.Id("rightHandSidePanel"));
                    var clickyClicky = mainHeader.FindElement(By.LinkText("Azure Resources"));
                    clickyClicky.Click();
                }

            } else {

            }

            bool IsElementPresent(By by)
            {
                try
                {
                    driver.FindElement(by);
                    treePresent = true;
                    return true;
                }
                catch (NoSuchElementException)
                {
                    treePresent = false;
                    return false;
                }
            }


        }
            /*public static void retryingFindClick(By by)
            {
            IWebDriver driver = new FirefoxDriver();
            Boolean result = false;
                int attempts = 0;
                while (attempts < 2)
                {
                    try
                    {
                        // find sign in button
                        var signIn = driver.FindElement(by);
                        // clicks button
                        signIn.Click();
                        // button clicked, confirms result
                        result = true;
                        break;
                    }
                    catch (StaleElementReferenceException e)
                    {

                    }
                    attempts++;
                }
            }*/          
        }
    }
